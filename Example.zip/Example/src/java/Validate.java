/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author G 50
 */
import java.sql.*;
public class Validate {
    public static boolean checkUser(String email,String pass) 
     {
      boolean st =false;
      try{

	 //loading drivers for mysql
         Class.forName("org.apache.derby.jdbc.ClientDriver");

 	 //creating connection with the database 
         Connection con=DriverManager.getConnection
                       ("jdbc:derby://localhost:1527/Example", "ad", "ad");
         PreparedStatement ps =con.prepareStatement
                             ("select * from Customer where email=? and pass=?");
         ps.setString(1, email);
         ps.setString(2, pass);
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(Exception e)
      {
          e.printStackTrace();
      }
         return st;                 
  }   
public static String httpSession(String email)
    {
        String name=null;
        try{

	 //loading drivers for mysql
         Class.forName("org.apache.derby.jdbc.ClientDriver");

 	 //creating connection with the database 
         Connection con=DriverManager.getConnection
                       ("jdbc:derby://localhost:1527/Example", "ad", "ad");
         PreparedStatement ps =con.prepareStatement
                             ("select firstname from customer where email=?");
         ps.setString(1, email);
        
         
         ResultSet rs = ps.executeQuery();
         while(rs.next())
         {
         name=rs.getString("firstname");
         
         }
             
         
                 
      }catch(Exception e)
      {
          e.printStackTrace();
      }
        return name;
    }
}
    


