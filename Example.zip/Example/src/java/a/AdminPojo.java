/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author G 50
 */
public class AdminPojo {
    public void insert(int id, String name, String show, String time, String city) throws ClassNotFoundException, SQLException {
         
             String qu="insert into Admin values(?,?,?,?,?)";
               Class.forName("org.apache.derby.jdbc.ClientDriver");
               Connection c=DriverManager.getConnection("jdbc:derby://localhost:1527/Admin","ad","ad");
             PreparedStatement ps=c.prepareStatement(qu);
            
             ps.setInt(1, id);
             ps.setString(2, name);
             ps.setString(3, show);
             ps.setString(4, time);
             ps.setString(5, city);
             int r=ps.executeUpdate();
           
    }
    public void delete(int id) throws ClassNotFoundException, SQLException {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
               Connection c=DriverManager.getConnection("jdbc:derby://localhost:1527/Admin","ad","ad");
               String command="delete from Admin where id=?";
               PreparedStatement ps=c.prepareStatement(command);
               ps.setInt(1,id);

              int count=ps.executeUpdate();
    }
    
}
