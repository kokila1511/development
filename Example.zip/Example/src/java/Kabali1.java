import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Kabali1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String uname = request.getParameter("uname");
        String date = request.getParameter("date");
        String time=request.getParameter("time");
        String totalprice=request.getParameter("totalprice");
        String[] seat=request.getParameterValues("seat");
        for(String s:seat)
       
        
        try{
        
        //loading drivers for mysql
         Class.forName("org.apache.derby.jdbc.ClientDriver");

	//creating connection with the database 
          Connection  con=DriverManager.getConnection
                      ("jdbc:derby://localhost:1527/MovieDB", "db", "db");

        PreparedStatement ps=con.prepareStatement
                  ("insert into Kabali values(?,?,?,?,?)");

        ps.setString(1, uname);
         ps.setString(2, date);
          ps.setString(3, time);
          ps.setString(4, totalprice);
          ps.setString(5, s);
       
   
        int i=ps.executeUpdate();
        
          if(i>0)
          {
            RequestDispatcher rs=request.getRequestDispatcher("Payment.jsp");
            rs.forward(request, response);
          }
          else
          {
              System.out.println("invalid");
          }
        
        }
        catch(Exception se)
        {
            se.printStackTrace();
        }
        }
}

    