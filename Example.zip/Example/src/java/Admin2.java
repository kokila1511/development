/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;


/**
 *
 * @author G 50
 */
public class Admin2 extends HttpServlet {

   protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String id = request.getParameter("id");
        String name = request.getParameter("tname");
        String show = request.getParameter("sname");
        String time = request.getParameter("time");
        String city = request.getParameter("city");
        try{
        
        //loading drivers for mysql
         Class.forName("org.apache.derby.jdbc.ClientDriver");

	//creating connection with the database 
          Connection  con=DriverManager.getConnection
                      ("jdbc:derby://localhost:1527/Admin", "ad", "ad");

        PreparedStatement ps=con.prepareStatement
                  ("insert into Admin values(?,?,?,?,?)");

        ps.setString(1, id);
         ps.setString(2, name);
          ps.setString(3,show);
        ps.setString(4, time);
        ps.setString(5, city);
        int i=ps.executeUpdate();
        
          if(i>0)
          {
            RequestDispatcher rs=request.getRequestDispatcher("Adminopt.jsp");
            rs.forward(request, response);
          }
        
        }
        catch(Exception se)
        {
            se.printStackTrace();
        }
   
        }
    }

    