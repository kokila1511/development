/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author G 50
 */
public class Payment extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           String bank=request.getParameter("bank");
            if(bank.compareTo("sbi")==0)
            {
             String sbi="STATE BANK OF INDIA";
             String card=request.getParameter("card");
            if(card.compareTo("credit")==0){
                System.out.println(sbi);
                 System.out.println("<h1>ENTER UR CREDIT CARD DETAILS<h1>");
             RequestDispatcher rd=request.getRequestDispatcher("creditcard.jsp");
             rd.include(request, response);
            }
            else{
                System.out.println(sbi);
                System.out.println("<h1>ENTER UR DEBIT CARD DETAILS<h1>");
                RequestDispatcher rd=request.getRequestDispatcher("debitcard.jsp");
             rd.include(request, response);
                
            }
            }
            if(bank.compareTo("icici")==0)
            {
             String icici="ICICI";
            
            
            
             String card=request.getParameter("card");
            if(card.compareTo("credit")==0){
                 System.out.println(icici);
                 System.out.println("<h1>ENTER UR CREDIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("creditcard.jsp");
             rs.include(request, response);
            }
            else{
                 System.out.println(icici);
                 System.out.println("<h1>ENTER UR DEBIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("debitcard.jsp");
             rs.include(request, response);
            }  }
            if(bank.compareTo("indian")==0)
            {
             String indian="INDIAN BANK";
            
         
            
             String card=request.getParameter("card");
            if(card.compareTo("credit")==0){
                 System.out.println(indian);
                 System.out.println("<h1>ENTER UR CREDIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("credit.jsp");
             rs.include(request, response);
            }
            else{
                System.out.println(indian);
                System.out.println("<h1>ENTER UR DEBIT CARD DETAILS<h1>");
             RequestDispatcher rs=request.getRequestDispatcher("debitcard.jsp");
             rs.include(request, response);
            }  
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
